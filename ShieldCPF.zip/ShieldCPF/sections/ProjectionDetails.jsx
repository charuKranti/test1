import React from "react";
import { Grid } from "@material-ui/core";
import MaterialTable from "material-table";
import Tooltip from "@material-ui/core/Tooltip";
import { makeStyles } from "@material-ui/core";
import "./shieldCpf.css";
const useStyles = makeStyles((theme) => ({
  lightTooltip: {
    background: "#ffffff",
    color: "#000",
    fontSize: 11,
    width: "220px",
    padding: "5% 0% 5% 10%",
  },
}));
const ProjectionDetails = () => {
  const classes = useStyles();

  const exData = [
    { label: "Medishield Life Premium", value: "2,348.00" },
    { label: "Medishield Life Subsidy Amount", value: "2,348.00" },
    { label: "Medishield Life Premium(Nett)", value: "2,348.00" },
  ];
  return (
    <MaterialTable
      title=""
      columns={[
        { title: "Request Date", field: "requestDate", sorting: false },
        { title: "Extraction Date", field: "extractionDate", sorting: false },
        { title: "Return Date", field: "returnDate", sorting: false },
        { title: "Status", field: "status", sorting: false },
        { title: "Requestor", field: "requestor", sorting: false },
        { title: "Manual", field: "manual", sorting: false },
        { title: "Remark", field: "remark", sorting: false },
      ]}
      data={[
        {
          requestDate: "DD/MM/YYYY",
          extractionDate: "DD/MM/YYYY",
          returnDate: "DD/MM/YYYY",
          status: "Pending",
          requestor: "Pending",
          manual: "Yes",
          remark: "Name",
          extendedData: exData,
        },
        {
          requestDate: "DD/MM/YYYY",
          extractionDate: "DD/MM/YYYY",
          returnDate: "DD/MM/YYYY",
          status: "Approved",
          requestor: "Pending",
          manual: "No",
          remark: "Name",
          extendedData: exData,
        },
        {
          requestDate: "DD/MM/YYYY",
          extractionDate: "DD/MM/YYYY",
          returnDate: "DD/MM/YYYY",
          status: "Submitted",
          requestor: "Pending",
          manual: "Yes",
          remark: "Name",
          extendedData: exData,
        },
        {
          requestDate: "DD/MM/YYYY",
          extractionDate: "DD/MM/YYYY",
          returnDate: "DD/MM/YYYY",
          status: "Pending",
          requestor: "Pending",
          manual: "No",
          remark: "Name",
          extendedData: exData,
        },
        {
          requestDate: "DD/MM/YYYY",
          extractionDate: "DD/MM/YYYY",
          returnDate: "DD/MM/YYYY",
          status: "Approved",
          requestor: "Pending",
          manual: "Yes",
          remark: "Name",
          extendedData: exData,
        },
      ]}
      options={{
        actionsColumnIndex: -1,
        search: false,
        exportButton: true,
        grouping: false,
        filtering: false,
        paging: false,
        sorting: true,
        draggable: false,
        maxBodyHeight: "200px",
        toolbar: false,
        showTextRowsSelected: false,
        rowStyle: {
          height: 40,
        },

        headerStyle: {
          whiteSpace: "nowrap",
          backgroundColor: "#8d9aac",
          color: "#ffffff",
          height: 40,
        },
      }}
      detailPanel={[
        {
          tooltip: "Show Name",
          render: (rowData) => {
            return (
              <div
                style={{
                  fontSize: 13,
                  textAlign: "justify",
                  color: "#000000",
                  backgroundColor: "#EEF0F1",
                  marginTop: "-1px",
                  fontFamily: "Open Sans,Regular",
                  marginLeft: "-6px",
                  marginRight: "-6px",
                  padding: "0px 0px 0px 100px",
                }}
              >
                <Grid container item>
                  {rowData.extendedData.map((val, i) => {
                    const longText = (
                      <Grid container>
                        <Grid item sm={6}>
                          <div>MSHL-MERDEKA</div>
                          <div>157.40</div>
                          <div>MSHL-PIONEER</div>
                          <div>41.22</div>
                        </Grid>
                        <Grid item sm={6}>
                          <div>MSHL-TRAN</div>
                          <div>32.32</div>
                          <div>MSHL-PREM</div>
                          <div>112.98</div>
                        </Grid>
                      </Grid>
                    );
                    return (
                      <Grid key={i} item>
                        <Tooltip
                          title={longText}
                          classes={{ tooltip: classes.lightTooltip }}
                          arrow
                        >
                          <p className="semibold font-13 font-black margin-right-40 margin-top-16">
                            {val.label}
                          </p>
                        </Tooltip>
                        <p className="regular font-15 font-black">
                          {val.value}
                        </p>
                      </Grid>
                    );
                  })}
                </Grid>
              </div>
            );
          },
        },
      ]}
    />
  );
};

export default ProjectionDetails;
