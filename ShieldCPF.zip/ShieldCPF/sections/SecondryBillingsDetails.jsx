import React, { useState } from "react";
import { Grid, Divider } from "@material-ui/core";
import ReadOnlyTextfieldList from "../../../ReusableComponents/ReadOnlyTextfieldList";
import TextFieldComponent from "../../../ReusableComponents/TextField";
import "./shieldCpf.css";
const BillingChangesSection = () => {
  const [state, setState] = React.useState({
    secondryBilling: '88500923',
    nextMop: 'XXXX-XXXX-XXXXX',
    secInstPrem: 'Lorem Ispum',
    mandateRef: 'Lorem Ispum',
    billingRef: 'Lorem Ispum',
    mandateStatus: 'Lorem Ispum',
    factoringHouse: 'Lorem Ispum',
    bankCode: 'Lorem Ispum',
    accountNumber: 'Lorem Ispum',
    expiryDate: 'Lorem Ispum',
  });

  const textFieldConfig = [
    { label: "Secondary Billing Channel", value: state.secondryBilling, name: "secondryBilling", disabled: false },
    { label: "Next MOP", value: state.nextMop, name: "nextMop", disabled: false },
    { label: "Sec Ch Inst Prem ", value: state.secInstPrem, name: "secInstPrem", disabled: false },
    { label: "Mandate Ref No.", value: state.mandateRef, name: "nextMop", disabled: true },
    { label: "Billing Ref No.", value: state.billingRef, name: "billingRef", disabled: true },
    { label: "Mandate Status", value: state.mandateRef, name: "mandateRef", disabled: true },
    { label: "Factoring House", value: state.factoringHouse, name: "factoringHouse", disabled: true },
    { label: "Bank Code", value: state.bankCode, name: "bankCode", disabled: true },
    { label: "Account Number", value: state.accountNumber, name: "accountNumber", disabled: true },
    { label: "Expiry Date", value: state.expiryDate, name: "expiryDate", disabled: true },
  ];

  const handleChange = (e) => {
    setState({ ...state, [e.target.name]: e.target.value })
  }

  const handleTextDate = () => {
    if (textFieldConfig && textFieldConfig.length > 0) {
      return textFieldConfig.map((val, i) => {
        return (<Grid item sm={3} key={i}>
          <TextFieldComponent className="field-text-g" fullWidth value={val.value} label={val.label} disabled={val.disabled} name={val.name} onChange={handleChange} />
        </Grid>
        )
      })
    }
  }

  const inputDataDebit = [
    { label: "Mandate ID", value: "308.00" },
    { label: "Bill Ref", value: "00.00" },
    { label: "Bank Code", value: "28.00" },
    { label: "Account", value: "50.00" }
  ];

  const handleFixDate = (event) => {
    setState({ ...state, [event.target.name]: event.target.value });
  };

  return (
    <Grid container spacing={2}>
      <Grid container sm={12} item spacing={2}>{handleTextDate()}</Grid>
      <Grid item xs={12} className="selection-view table-default-view" spacing={2}>
        <Divider className="divider" />
      </Grid>
      <Grid item xs={12} className="selection-view table-default-view">
        <div className="projectionTitle pl-1">Debit Details</div>
        <ReadOnlyTextfieldList sm={3} textFieldConfig={inputDataDebit} />
      </Grid>
    </Grid>
  );
};

export default BillingChangesSection;
