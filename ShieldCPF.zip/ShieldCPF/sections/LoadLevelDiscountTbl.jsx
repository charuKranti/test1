import React , {useState} from "react";
import { Grid } from "@material-ui/core";
import MaterialTable from "material-table";

const LoadLevelDiscountTbl = () => {

   const [inputText, setText] = useState(10)
    const tableColumns = [
        { title: "", field: "column", cellStyle: { backgroundColor: '#9badc7', color: '#FFF' }},
        { title: "Current", field: "current" },
        { title: "New", field: "new", render: () => {
            return (
                <Grid container item sm={2} className="fund-percentage">
                    <input type="text" id="new" name="new" value={inputText} onChange={(e)=>setText(e.target.value)} />
                </Grid>
            )
        } }
    ]

    const tableData = [
        { column: "Transaction number", current: "0.00", new: "0.00" },
        { column: "Transaction code", current: "0.00", new: "0.00" },
        { column: "Rerate date", current: "0.00", new: "0.00" },
        { column: "Load Level", current: "0.00", new: "0.00" },
        { column: "Exempt", current: "0.00", new: "0.00" },
        { column: "Load %", current: "0.00", new: "0.00" },
        { column: "Dicount %", current: "0.00", new: "0.00" },
    ]


    return (
        <Grid container spacing={1}>
            <Grid item sm={12}>
                <Grid container>
                    <Grid item sm={12}>
                        <MaterialTable
                            columns={tableColumns}
                            data={tableData}
                            options={{
                                search: false,
                                exportButton: true,
                                grouping: false,
                                filtering: false,
                                paging: false,
                                sorting: false,
                                draggable: false,
                                maxBodyHeight: "200px",
                                toolbar: false,
                                showTextRowsSelected: false,
                                rowStyle: {
                                    height: "40px"
                                },
                                headerStyle: {
                                    backgroundColor: "#6a83a7",
                                    color: "#FFFFFF",
                                    height: "40px",
                                    whiteSpace: "nowrap"
                                }
                            }}
                        />
                    </Grid>
                </Grid>
            </Grid>
        </Grid>
    )
};

export default LoadLevelDiscountTbl;
