import React from "react";
import { Grid} from "@material-ui/core";
import TextFieldComponent from "../../../ReusableComponents/TextField";
import "./shieldCpf.css";
const ManualDeductionAdjustment = () => {

  const [state, setState] = React.useState({
    startRenewal: '88500923',
    endDate: 'XXXX-XXXX-XXXXX',
    fixDate: 'Lorem Ispum',
    transactionType: 'Lorem Ispum',
    reasonDate: 'Lorem Ispum',
    interest: 'Lorem Ispum',
    planType: 'Lorem Ispum',
    DeductFrom: 'Lorem Ispum',
    refundFrom: 'Lorem Ispum',
    refundIPMI: 'Lorem Ispum',
    deductIMSH: 'Lorem Ispum',
    approvalDate: 'Lorem Ispum',
    suppressLetter: 'Lorem Ispum',
    delete: 'Lorem Ispum',
  });


  const inputData = [
    { label: "Start/Renewal date", value: state.startRenewal, name: "startRenewal", disabled: true },
    { label: "End Date",value: state.endDate, name: "endDate", disabled: true },
    { label: "Fix date", value: state.fixDate, name: "fixDate", disabled: true },
    { label: "Transaction type", value: state.transactionType, name: "transactionType", disabled: true },
    { label: "Reason code",value: state.reasonDate, name: "reasonDate", disabled: true },
    { label: "Interest",value: state.interest, name: "interest", disabled: true },
    { label: "Plan type", value: state.planType, name: "planType", disabled: true },
    { label: "Deduct from medisave (IPMI)",value: state.DeductFrom, name: "DeductFrom", disabled: true },
    { label: "Refund to medisave (IMSh)",value: state.refundFrom, name: "refundFrom", disabled: true },
    { label: "Refund to medisave (IPMI)",value: state.refundIPMI, name: "refundIPMI", disabled: true },
    { label: "Deduct from Medisave(IMSH )",value: state.deductIMSH, name: "deductIMSH", disabled: true },
    { label: "Approval date ", value: "00.00" ,value: state.approvalDate, name: "approvalDate", disabled: true },
    { label: "Suppress letter", value: "28.00" ,value: state.suppressLetter, name: "suppressLetter", disabled: false   },
    { label: "Delete", value: "50.00",value: state.delete, name: "delete", disabled: false }
  ];

 
 
  const handleChange = (e) => {
    setState({ ...state, [e.target.name]: e.target.value })
  }

  const handleTextDate = () => {
    if (inputData && inputData.length > 0) {
      return inputData.map((val, i) => {
        return (<Grid item sm={3} key={i}>
          <TextFieldComponent className="field-text-g" fullWidth value={val.value} label={val.label} disabled={val.disabled} name={val.name} onChange={handleChange} />
        </Grid>
        )
      })
    }
  }
  
 
  return (
    <Grid container spacing={2}>
        <Grid container sm={12} item spacing={2}>{handleTextDate()}</Grid>
    </Grid>
  );
};

export default ManualDeductionAdjustment;
