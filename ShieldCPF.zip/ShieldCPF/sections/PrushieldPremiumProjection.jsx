import React, { useState } from "react";
import { Grid, Divider, Button } from "@material-ui/core";
import ProjectionDetails from "./ProjectionDetails";
import FormControl from "@material-ui/core/FormControl";
import FormLabel from "@material-ui/core/FormLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import ReadOnlyTextfieldList from "../../../ReusableComponents/ReadOnlyTextfieldList";
import TextFieldComponent from '../../../ReusableComponents/TextField';
import "./shieldCpf.css";
const PrushieldPremiumProjection = () => {
  const premiumProjection = {
    fixDate: "",
    supressLetter: "",
  };
  const inputData = [
    { label: "Client Number", value: "88500923" },
    { label: "Owner Name", value: "Abdul Halim" },
    { label: "Owner NRIC", value: "S23" },
    { label: "Owner Nationality", value: "00.00" },
    { label: "Client Number", value: "43.00" },
    { label: "Payer Name", value: "234.00" },
    { label: "Payer NRIC", value: "423.00" },
    { label: "Payer Nationality", value: "00.00" },
    { label: "Client Number", value: "1,321.00" },
    { label: "Life Assured Name", value: "2,348.00" },
    { label: "Life Assured NRIC", value: "308.00" },
    { label: "Life Assured Nationality", value: "00.00" },
    { label: "Child Medisave", value: "28.00" },
    { label: "Owner CPF Account Number", value: "50.00" },
    { label: "Child CPF Account Number", value: "50.00" },
    { label: "Payer CPF Account Number", value: "50.00" },
    { label: "Inception Date", value: "50.00" },
    { label: "Plan Component", value: "50.00" },
    { label: "Premium Eff Date ", value: "88500923" },
  ];
  const [state, setState] = useState(premiumProjection);
  const handleFixDate = (event) => {
    setState({ ...state, [event.target.name]: event.target.value });
  };
  return (
    <Grid className="row-throwback">
      <Grid container item className="grid-container-fields">
        <ReadOnlyTextfieldList sm={3} textFieldConfig={inputData} />
        <Grid item xs={12} className="selection-view table-default-view">
          <Divider className="divider" />
        </Grid>
        <Grid item xs={12} className="selection-view table-default-view">
          <div className="projectionTitle">Projection Details</div>
          <ProjectionDetails />
          <div className="retriggerPremium"> Retrigger Premium Projection</div>
        </Grid>
        <Grid item sm={3}>
          <TextFieldComponent disabled className="field-text-g prushieldPremiumProjectionInput" name="deductFromMidSaveIPMI" value="DD/MM/YYYY" label="Inception Date" />
        </Grid>
        <Grid item sm={2}>
          <FormControl component="fieldset" className="fix-date-fieldset">
            <FormLabel className="fixDateLabel">Fix Date</FormLabel>
            <RadioGroup
              row
              aria-label="Add-to-Concurrent-Policies"
              name="fixDate"
              value={state.fixDate}
              onChange={handleFixDate}
            >
              <FormControlLabel
                className="radio-button-label"
                value="yes"
                control={<Radio />}
                label={<span className="FS14">Yes</span>}
                labelPlacement="end"
                size="small"
              />
              <FormControlLabel
                className="radio-button-label"
                value="no"
                control={<Radio />}
                label={<span className="FS14">No</span>}
                labelPlacement="end"
                size="small"
              />
            </RadioGroup>
          </FormControl>
        </Grid>
        <Grid item sm={2}>
          <FormControl component="fieldset" className="fix-date-fieldset">
            <FormLabel className="fixDateLabel">Supress Letter</FormLabel>
            <RadioGroup
              row
              aria-label="Add-to-Concurrent-Policies"
              name="supressLetter"
              value={state.supressLetter}
              onChange={handleFixDate}
            >
              <FormControlLabel
                className="radio-button-label"
                value="supressyes"
                control={<Radio />}
                label={<span className="FS14">Yes</span>}
                labelPlacement="end"
                size="small"
              />
              <FormControlLabel
                className="radio-button-label"
                value="supressno"
                control={<Radio />}
                label={<span className="FS14">No</span>}
                labelPlacement="end"
                size="small"
              />
            </RadioGroup>
          </FormControl>
        </Grid>
        <Grid item sm={3}>
          <Button className="btn-primary-blue-g retriggerButton">
            Retrigger Premium Projection
          </Button>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default PrushieldPremiumProjection;
