import React from "react";
import { Grid, TableCell, TableRow, TableFooter } from "@material-ui/core";
import MaterialTable, { MTableBody } from "material-table";

const BillingChangesTbl = () => {


    const fundDetailsData = [
        {
            life: "Lorem",
            cov: "Lorem",
            rider: "Lorem",
            type: "Lorem",
            fundCode: "Lorem",
            fundCurrency: "Lorem",
        },
        {
            life: "Lorem",
            cov: "Lorem",
            rider: "Lorem",
            type: "Lorem",
            fundCode: "Lorem",
            fundCurrency: "Lorem",
        },
    ]

    const FundColumns = [
        { title: "Code", field: "life", sorting: false },
        { title: "Description", field: "cov", sorting: false },
        { title: "Yearly", field: "rider", sorting: false },
        { title: "Half Yearly", field: "type", sorting: false },
        { title: "Quarterly", field: "fundCode", sorting: false },
        { title: "Monthly", field: "fundCurrency", sorting: false },

    ];

    const tableColumns = [
        { title: "", field: "column", cellStyle: { backgroundColor: '#9badc7', color: '#FFF' } },
        { title: "", field: "yearly" },
        { title: "", field: "halfyearly" },
        { title: "", field: "quarterly" },
        { title: "", field: "monthly" },
    ]

    const tableData = [
        { column: "Gross Premium", yearly: "0.00", halfyearly: "0.00", quarterly: "0.00", monthly: "0.00" },
        { column: "Fee", yearly: "0.00", halfyearly: "0.00", quarterly: "0.00", monthly: "0.00" },
        { column: "Discount", yearly: "0.00", halfyearly: "0.00", quarterly: "0.00", monthly: "0.00" },
        { column: "Total Premium", yearly: "0.00", halfyearly: "0.00", quarterly: "0.00", monthly: "0.00" }
    ]



    return (
        <Grid container spacing={1}>

            <Grid item sm={12} className="load-discount-table">
                <MaterialTable
                    className="load-discount-table"
                    columns={FundColumns}
                    data={fundDetailsData}
                    components={{
                        Body: (props) => (
                            <>
                                <MTableBody {...props} />
                                <TableFooter>
                                    <TableRow>
                                        <TableCell colSpan={1} />
                                        <TableCell colSpan={5} className="footer-discount-tbl"> <MaterialTable
                                            columns={tableColumns}
                                            data={tableData}
                                            options={{
                                                search: false,
                                                exportButton: true,
                                                grouping: false,
                                                filtering: false,
                                                paging: false,
                                                sorting: false,
                                                draggable: false,
                                                toolbar: false,
                                                showTextRowsSelected: false,
                                                rowStyle: {
                                                    height: "40px"
                                                },
                                                headerStyle: {
                                                    color: "#FFFFFF",
                                                    height: "40px",
                                                }
                                            }}
                                        />
                                        </TableCell>
                                    </TableRow>

                                </TableFooter>
                            </>
                        )
                    }}
                    options={{
                        actionsColumnIndex: -1,
                        exportButton: true,
                        grouping: false,
                        search: false,
                        filtering: false,
                        paging: false,
                        pageSize: 5,
                        pageSizeOptions: [5],
                        tableLayout: "auto",
                        toolbar: false,
                        showTextRowsSelected: false,
                        maxBodyHeight: "450px",
                        headerStyle: {
                            backgroundColor: "#6a83a7",
                            textAlign: "center",
                            color: "#FFFF",
                            position: "sticky",
                            height: "40px",
                            top: 0,
                            width: 2
                        },
                        rowStyle: {
                            height: "40px",
                            textAlign: "center"
                        }
                    }}
                />
            </Grid>
        </Grid>
    )
};

export default BillingChangesTbl;
