import React, { useState } from "react";
import { Grid, Divider } from "@material-ui/core";
import TextFieldComponent from "../../../ReusableComponents/TextField";
import BillingChangesTbl from "./BillingChangesTbl"
import "./shieldCpf.css";
const BillingChangesSection = () => {
    const [state, setState] = React.useState({
        method: '657484',
        frequency: 'XXXX-XXXX-XXXXX'
    });

    const textFieldConfig = [
        { label: "Method", value: state.method, name: "method", disabled: false },
        { label: "Frequency", value: state.frequency, name: "frequency", disabled: false },
    ];
    const handleChange = (e) => {
        setState({ ...state, [e.target.name]: e.target.value })
    }

    const handleTextDate = () => {
        if (textFieldConfig && textFieldConfig.length > 0) {
            return textFieldConfig.map((val, i) => {
                return (<Grid item sm={3} key={i}>
                    <TextFieldComponent className="field-text-g" fullWidth value={val.value} label={val.label} name={val.name} onChange={handleChange} disabled={val.disabled} />
                </Grid>
                )
            })
        }
    }

    return (
        <Grid container spacing={2}>
            <Grid container sm={12} item spacing={2}>{handleTextDate()}</Grid>
            <Grid item xs={12} className="selection-view table-default-view">
                <Divider className="divider" />
            </Grid>
            <Grid item xs={12} className="selection-view table-default-view" spacing={2}>
                <BillingChangesTbl/>
            </Grid>
        </Grid>
    );
};

export default BillingChangesSection;
