import React, { useState } from "react";
import { Grid} from "@material-ui/core";
import LoadLevelDiscountTbl from "./LoadLevelDiscountTbl"
import "./shieldCpf.css";
const PremiumProjectiion = () => {
  const premiumProjection = {
    fixDate: "",
    supressLetter: "",
  };
  const inputData = [
    { label: "Premium Eff Date ", value: "88500923" },
  ];
  const [state, setState] = useState(premiumProjection);
  const handleFixDate = (event) => {
    setState({ ...state, [event.target.name]: event.target.value });
  };
  return (
    <Grid container spacing={2}>
      <Grid sm={12} item>
        <LoadLevelDiscountTbl/>
      </Grid>
    </Grid>
  );
};

export default PremiumProjectiion;
