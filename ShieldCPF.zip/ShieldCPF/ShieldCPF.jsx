import { Grid } from "@material-ui/core";
import React from "react";
import AccordionListComponent from "../../ReusableComponents/AccordionListComponent";
import PrushieldPremiumProjection from "./sections/PrushieldPremiumProjection.jsx";
import Deduction from "./sections/CpfDeduction.jsx";
import ManualDeduction from "./sections/CpfManualDeducation";
import Decision from "./sections/CpfDecision";
import SecondryBilling from "./sections/SecondryBillingsDetails"
import BillingChangesSection from "./sections/BillingChangesSection"
import ManualDeductionAdjustment from "./sections/ManualDeductionAdjustment";
import LoadLevelDiscountSection from "./sections/LoadLevelDiscountSection"

const ShieldCPF = () => {
  const config = [
    {label: "Premium Projection and other details",component: <PrushieldPremiumProjection />,
    },
    { label: "Deduction", component: <Deduction /> },
    { label: "Manual Deduction", component: <ManualDeduction /> },
    { label: "Secondary Billing details",component: <SecondryBilling />},
    { label: "Billing Changes Section/fields",component: <BillingChangesSection />},
    { label: "Manual deduction / Adjustment deletion ",component: <ManualDeductionAdjustment />},
    { label: "Load Level Discount Section/fields",component: <LoadLevelDiscountSection />},
    { label: "Case Decision", component: <Decision /> },
  ];

  return (
    <Grid container spacing={1}>
      <AccordionListComponent data={config} />
    </Grid>
  );
};

export default ShieldCPF;
